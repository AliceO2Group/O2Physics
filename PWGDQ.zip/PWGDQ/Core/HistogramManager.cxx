// Copyright 2019-2020 CERN and copyright holders of ALICE O2.
// See https://alice-o2.web.cern.ch/copyright for details of the copyright holders.
// All rights not expressly granted are reserved.
//
// This software is distributed under the terms of the GNU General Public
// License v3 (GPL Version 3), copied verbatim in the file "COPYING".
//
// In applying this license CERN does not waive the privileges and immunities
// granted to it by virtue of its status as an Intergovernmental Organization
// or submit itself to any jurisdiction.

#include "PWGDQ/Core/HistogramManager.h"

#include <Framework/Logger.h>

#include <TArrayD.h>
#include <TClass.h>
#include <TCollection.h>
#include <TH1.h>
#include <TH2.h>
#include <TH3.h>
#include <THashList.h>
#include <THn.h>
#include <THnBase.h>
#include <THnSparse.h>
#include <TIterator.h>
#include <TNamed.h>
#include <TObjArray.h>
#include <TObject.h>
#include <TProfile.h>
#include <TProfile2D.h>
#include <TProfile3D.h>
#include <TString.h>

#include <Rtypes.h>
#include <RtypesCore.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <list>
#include <memory>
#include <span>
#include <vector>

//_______________________________________________________________________________
HistogramManager::HistogramManager() : TNamed("", ""),
                                       fMainList(nullptr),
                                       fNVars(0),
                                       fUsedVars(nullptr),
                                       fUseDefaultVariableNames(false),
                                       fBinsAllocated(0)
{
  //
  // Constructor
  //
}

//_______________________________________________________________________________
HistogramManager::HistogramManager(const char* name, const char* title, const int maxNVars) : TNamed(name, title),
                                                                                              fMainList(new THashList),
                                                                                              fNVars(maxNVars),
                                                                                              fUsedVars(new bool[maxNVars]),

                                                                                              fUseDefaultVariableNames(kFALSE),
                                                                                              fBinsAllocated(0)
{
  //
  // Constructor
  //

  fMainList->SetOwner(kTRUE);
  fMainList->SetName(name);

  for (int i = 0; i < maxNVars; ++i) {
    fUsedVars[i] = false;
  }
  fVariableNames.resize(maxNVars);
  fVariableUnits.resize(maxNVars);
}

//_______________________________________________________________________________
HistogramManager::~HistogramManager()
{
  //
  // De-constructor
  //
  delete fMainList;
  delete[] fUsedVars;
}

//_______________________________________________________________________________
void HistogramManager::SetDefaultVarNames(TString* vars, TString* units)
{
  //
  // Set default variable names
  //
  std::span<TString> varNames{vars, static_cast<std::size_t>(fNVars)};
  std::span<TString> varUnits{units, static_cast<std::size_t>(fNVars)};
  for (int i = 0; i < fNVars; ++i) {
    fVariableNames[i] = varNames[i];
    fVariableUnits[i] = varUnits[i];
  }
};

//__________________________________________________________________
void HistogramManager::AddHistClass(const char* histClass)
{
  //
  // Add a new histogram list
  //
  if (fMainList->FindObject(histClass)) {
    LOG(warn) << "HistogramManager::AddHistClass(): Cannot add histogram class " << histClass
              << " because it already exists.";
    return;
  }
  auto* hList = new TList;
  hList->SetOwner(kTRUE);
  hList->SetName(histClass);
  fMainList->Add(hList);
  std::list<std::vector<int>> varList;
  fVariablesMap[histClass] = varList;
}

//_________________________________________________________________
void HistogramManager::AddHistogram(const char* histClass, const char* hname, const char* title, bool isProfile,
                                    int nXbins, double xmin, double xmax, int varX,
                                    int nYbins, double ymin, double ymax, int varY,
                                    int nZbins, double zmin, double zmax, int varZ,
                                    const char* xLabels, const char* yLabels, const char* zLabels,
                                    int varT, int varW, bool isdouble, bool isFillLabelx)
{
  //
  // add a histogram  (this function can define TH1F,TH2F,TH3F,TProfile,TProfile2D, and TProfile3D)
  //
  // TODO: replace the cout warning messages with LOG (same for all the other functions)

  // get the list to which the histogram should be added
  auto* hList = dynamic_cast<TList*>(fMainList->FindObject(histClass));
  if (!hList) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram list " << histClass << " not found!";
    LOG(warn) << "         Histogram not created";
    return;
  }
  // check whether this histogram name was used before
  if (hList->FindObject(hname)) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram " << hname << " already exists in class " << histClass;
    return;
  }

  // deduce the dimension of the histogram from parameters
  // NOTE: in case of profile histograms, one extra variable is needed
  int dimension = 1;
  if (varY > kNothing) {
    dimension = 2;
  }
  if (varZ > kNothing) {
    dimension = 3;
  }

  // tokenize the title string; the user may include in it axis titles which will overwrite the defaults
  TString titleStr(title);
  std::unique_ptr<TObjArray> arr(titleStr.Tokenize(";"));
  // mark required variables as being used
  if (varX > kNothing) {
    fUsedVars[varX] = kTRUE;
  }
  if (varY > kNothing) {
    fUsedVars[varY] = kTRUE;
  }
  if (varZ > kNothing) {
    fUsedVars[varZ] = kTRUE;
  }
  if (varT > kNothing) {
    fUsedVars[varT] = kTRUE;
  }
  if (varW > kNothing) {
    fUsedVars[varW] = kTRUE;
  }

  // encode needed variable identifiers in a vector and push it to the std::list corresponding to the current histogram list
  std::vector<int> varVector;
  varVector.push_back(isProfile ? 1 : 0); // whether the histogram is a profile
  varVector.push_back(0);                 // whether it is a THn
  varVector.push_back(varW);              // variable used for weighting
  varVector.push_back(varX);              // variables on each axis
  varVector.push_back(varY);
  varVector.push_back(varZ);
  varVector.push_back(varT);                 // variable used for profiling in case of TProfile3D
  varVector.push_back(isFillLabelx ? 1 : 0); // whether to fill with the x-axis labels
  std::list varList = fVariablesMap[histClass];
  varList.push_back(varVector);
  fVariablesMap[histClass] = varList;

  // create and configure histograms according to required options
  TH1* h = nullptr;
  switch (dimension) {
    case 1: // TH1F
      if (!isdouble) {
        h = new TH1F(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax);
      } else {
        h = new TH1D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax);
      }
      fBinsAllocated += nXbins + 2;
      // TODO: possibly make the call of Sumw2() optional for all histograms
      h->Sumw2();
      if (fVariableNames[varX][0] != 0) {
        h->GetXaxis()->SetTitle(Form("%s %s", fVariableNames[varX].Data(),
                                     ((fVariableUnits[varX][0] != 0) ? Form("(%s)", fVariableUnits[varX].Data()) : "")));
      }
      if (arr->At(1)) {
        h->GetXaxis()->SetTitle(arr->At(1)->GetName());
      }
      if (xLabels[0] != '\0') {
        MakeAxisLabels(h->GetXaxis(), xLabels);
      }
      hList->Add(h);
      h->SetDirectory(nullptr);
      break;

    case 2: // either TH2F or TProfile
      if (isProfile) {
        h = new TProfile(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax);
        fBinsAllocated += nXbins + 2;
        h->Sumw2();
        // if requested, build the profile using the profile widths instead of stat errors
        // TODO: make this option more transparent to the user ?
        if (titleStr.Contains("--s--")) {
          if (auto* profile = dynamic_cast<TProfile*>(h)) {
            profile->BuildOptions(0., 0., "s");
          }
        }
      } else {
        if (!isdouble) {
          h = new TH2F(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax, nYbins, ymin, ymax);
        } else {
          h = new TH2D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax, nYbins, ymin, ymax);
        }
        fBinsAllocated += (nXbins + 2) * (nYbins + 2);
        h->Sumw2();
      }
      if (fVariableNames[varX][0] != 0) {
        h->GetXaxis()->SetTitle(Form("%s %s", fVariableNames[varX].Data(),
                                     ((fVariableUnits[varX][0] != 0) ? Form("(%s)", fVariableUnits[varX].Data()) : "")));
      }
      if (arr->At(1)) {
        h->GetXaxis()->SetTitle(arr->At(1)->GetName());
      }
      if (xLabels[0] != '\0') {
        MakeAxisLabels(h->GetXaxis(), xLabels);
      }

      if (fVariableNames[varY][0] != 0) {
        h->GetYaxis()->SetTitle(Form("%s %s", fVariableNames[varY].Data(),
                                     ((fVariableUnits[varY][0] != 0) ? Form("(%s)", fVariableUnits[varY].Data()) : "")));
      }
      if ((fVariableNames[varY][0] != 0) && isProfile) {
        h->GetYaxis()->SetTitle(Form("<%s> %s", fVariableNames[varY].Data(),
                                     ((fVariableUnits[varY][0] != 0) ? Form("(%s)", fVariableUnits[varY].Data()) : "")));
      }
      if (arr->At(2)) {
        h->GetYaxis()->SetTitle(arr->At(2)->GetName());
      }
      if (yLabels[0] != '\0') {
        MakeAxisLabels(h->GetYaxis(), yLabels);
      }
      hList->Add(h);
      h->SetDirectory(nullptr);
      break;

    case 3: // TH3F, TProfile2D or TProfile3D
      if (isProfile) {
        if (varT > kNothing) { // TProfile3D
          h = new TProfile3D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax, nYbins, ymin, ymax, nZbins, zmin, zmax);
          fBinsAllocated += (nXbins + 2) * (nYbins + 2) * (nZbins + 2);
          h->Sumw2();
          if (titleStr.Contains("--s--")) {
            if (auto* profile = dynamic_cast<TProfile3D*>(h)) {
              profile->BuildOptions(0., 0., "s");
            }
          }
        } else { // TProfile2D
          h = new TProfile2D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax, nYbins, ymin, ymax);
          fBinsAllocated += (nXbins + 2) * (nYbins + 2);
          h->Sumw2();
          if (titleStr.Contains("--s--")) {
            if (auto* profile = dynamic_cast<TProfile2D*>(h)) {
              profile->BuildOptions(0., 0., "s");
            }
          }
        }
      } else { // TH3F
        if (!isdouble) {
          h = new TH3F(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax, nYbins, ymin, ymax, nZbins, zmin, zmax);
        } else {
          h = new TH3D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xmin, xmax, nYbins, ymin, ymax, nZbins, zmin, zmax);
        }
        fBinsAllocated += (nXbins + 2) * (nYbins + 2) * (nZbins + 2);
        h->Sumw2();
      }
      if (fVariableNames[varX][0] != 0) {
        h->GetXaxis()->SetTitle(Form("%s %s", fVariableNames[varX].Data(),
                                     ((fVariableUnits[varX][0] != 0) ? Form("(%s)", fVariableUnits[varX].Data()) : "")));
      }
      if (arr->At(1)) {
        h->GetXaxis()->SetTitle(arr->At(1)->GetName());
      }
      if (xLabels[0] != '\0') {
        MakeAxisLabels(h->GetXaxis(), xLabels);
      }
      if (fVariableNames[varY][0] != 0) {
        h->GetYaxis()->SetTitle(Form("%s %s", fVariableNames[varY].Data(),
                                     ((fVariableUnits[varY][0] != 0) ? Form("(%s)", fVariableUnits[varY].Data()) : "")));
      }
      if (arr->At(2)) {
        h->GetYaxis()->SetTitle(arr->At(2)->GetName());
      }
      if (yLabels[0] != '\0') {
        MakeAxisLabels(h->GetYaxis(), yLabels);
      }
      if (fVariableNames[varZ][0] != 0) {
        h->GetZaxis()->SetTitle(Form("%s %s", fVariableNames[varZ].Data(),
                                     ((fVariableUnits[varZ][0] != 0) ? Form("(%s)", fVariableUnits[varZ].Data()) : "")));
      }
      if ((fVariableNames[varZ][0] != 0) && isProfile && varT < 0) { // for TProfile2D
        h->GetZaxis()->SetTitle(Form("<%s> %s", fVariableNames[varZ].Data(),
                                     ((fVariableUnits[varZ][0] != 0) ? Form("(%s)", fVariableUnits[varZ].Data()) : "")));
      }
      if (arr->At(3)) {
        h->GetZaxis()->SetTitle(arr->At(3)->GetName());
      }
      if (zLabels[0] != '\0') {
        MakeAxisLabels(h->GetZaxis(), zLabels);
      }
      h->SetDirectory(nullptr);
      hList->Add(h);
      break;

    default:
      LOG(warn) << "HistogramManager::AddHistogram(): Unsupported dimension " << dimension
                << " for histogram " << hname;
      return;
  } // end switch
}

//_________________________________________________________________
void HistogramManager::AddHistogram(const char* histClass, const char* hname, const char* title, bool isProfile,
                                    int nXbins, double* xbins, int varX,
                                    int nYbins, double* ybins, int varY,
                                    int nZbins, double* zbins, int varZ,
                                    const char* xLabels, const char* yLabels, const char* zLabels,
                                    int varT, int varW, bool isdouble, bool isFillLabelx)
{
  //
  // add a histogram
  //

  // get the list to which the histogram should be added
  auto* hList = dynamic_cast<TList*>(fMainList->FindObject(histClass));
  if (!hList) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram list " << histClass << " not found!";
    LOG(warn) << "         Histogram not created";
    return;
  }
  // check whether this histogram name was used before
  if (hList->FindObject(hname)) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram " << hname << " already exists";
    return;
  }

  // deduce the dimension of the histogram from parameters
  // NOTE: in case of profile histograms, one extra variable is needed
  int dimension = 1;
  if (varY > kNothing) {
    dimension = 2;
  }
  if (varZ > kNothing) {
    dimension = 3;
  }

  // mark required variables as being used
  if (varX > kNothing) {
    fUsedVars[varX] = kTRUE;
  }
  if (varY > kNothing) {
    fUsedVars[varY] = kTRUE;
  }
  if (varZ > kNothing) {
    fUsedVars[varZ] = kTRUE;
  }
  if (varT > kNothing) {
    fUsedVars[varT] = kTRUE;
  }
  if (varW > kNothing) {
    fUsedVars[varW] = kTRUE;
  }

  // tokenize the title string; the user may include in it axis titles which will overwrite the defaults
  TString titleStr(title);
  std::unique_ptr<TObjArray> arr(titleStr.Tokenize(";"));

  // encode needed variable identifiers in a vector and push it to the std::list corresponding to the current histogram list
  std::vector<int> varVector;
  varVector.push_back(isProfile ? 1 : 0); // whether the histogram is a profile
  varVector.push_back(0);                 // whether it is a THn
  varVector.push_back(varW);              // variable used for weighting
  varVector.push_back(varX);              // variables on each axis
  varVector.push_back(varY);
  varVector.push_back(varZ);
  varVector.push_back(varT);                 // variable used for profiling in case of TProfile3D
  varVector.push_back(isFillLabelx ? 1 : 0); // whether to fill with the x-axis labels
  std::list varList = fVariablesMap[histClass];
  varList.push_back(varVector);
  fVariablesMap[histClass] = varList;

  TH1* h = nullptr;
  switch (dimension) {
    case 1:
      if (!isdouble) {
        h = new TH1F(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins);
      } else {
        h = new TH1D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins);
      }
      fBinsAllocated += nXbins + 2;
      h->Sumw2();
      if (fVariableNames[varX][0] != 0) {
        h->GetXaxis()->SetTitle(Form("%s %s", fVariableNames[varX].Data(),
                                     ((fVariableUnits[varX][0] != 0) ? Form("(%s)", fVariableUnits[varX].Data()) : "")));
      }
      if (arr->At(1)) {
        h->GetXaxis()->SetTitle(arr->At(1)->GetName());
      }
      if (xLabels[0] != '\0') {
        MakeAxisLabels(h->GetXaxis(), xLabels);
      }
      h->SetDirectory(nullptr);
      hList->Add(h);
      break;

    case 2:
      if (isProfile) {
        h = new TProfile(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins);
        fBinsAllocated += nXbins + 2;
        h->Sumw2();
        if (titleStr.Contains("--s--")) {
          if (auto* profile = dynamic_cast<TProfile*>(h)) {
            profile->BuildOptions(0., 0., "s");
          }
        }
      } else {
        if (!isdouble) {
          h = new TH2F(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins, nYbins, ybins);
        } else {
          h = new TH2D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins, nYbins, ybins);
        }
        fBinsAllocated += (nXbins + 2) * (nYbins + 2);
        h->Sumw2();
      }
      if (fVariableNames[varX][0] != 0) {
        h->GetXaxis()->SetTitle(Form("%s %s", fVariableNames[varX].Data(),
                                     ((fVariableUnits[varX][0] != 0) ? Form("(%s)", fVariableUnits[varX].Data()) : "")));
      }
      if (arr->At(1)) {
        h->GetXaxis()->SetTitle(arr->At(1)->GetName());
      }
      if (xLabels[0] != '\0') {
        MakeAxisLabels(h->GetXaxis(), xLabels);
      }
      if (fVariableNames[varY][0] != 0) {
        h->GetYaxis()->SetTitle(Form("%s %s", fVariableNames[varY].Data(),
                                     ((fVariableUnits[varY][0] != 0) ? Form("(%s)", fVariableUnits[varY].Data()) : "")));
      }
      if ((fVariableNames[varY][0] != 0) && isProfile) {
        h->GetYaxis()->SetTitle(Form("<%s> %s", fVariableNames[varY].Data(),
                                     ((fVariableUnits[varY][0] != 0) ? Form("(%s)", fVariableUnits[varY].Data()) : "")));
      }

      if (arr->At(2)) {
        h->GetYaxis()->SetTitle(arr->At(2)->GetName());
      }
      if (yLabels[0] != '\0') {
        MakeAxisLabels(h->GetYaxis(), yLabels);
      }
      h->SetDirectory(nullptr);
      hList->Add(h);
      break;

    case 3:
      if (isProfile) {
        if (varT > kNothing) {
          h = new TProfile3D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins, nYbins, ybins, nZbins, zbins);
          fBinsAllocated += (nXbins + 2) * (nYbins + 2) * (nZbins + 2);
          h->Sumw2();
          if (titleStr.Contains("--s--")) {
            if (auto* profile = dynamic_cast<TProfile3D*>(h)) {
              profile->BuildOptions(0., 0., "s");
            }
          }
        } else {
          h = new TProfile2D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins, nYbins, ybins);
          fBinsAllocated += (nXbins + 2) * (nYbins + 2);
          h->Sumw2();
          if (titleStr.Contains("--s--")) {
            if (auto* profile = dynamic_cast<TProfile2D*>(h)) {
              profile->BuildOptions(0., 0., "s");
            }
          }
        }
      } else {
        if (!isdouble) {
          h = new TH3F(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins, nYbins, ybins, nZbins, zbins);
        } else {
          h = new TH3D(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nXbins, xbins, nYbins, ybins, nZbins, zbins);
        }
        fBinsAllocated += (nXbins + 2) * (nYbins + 2) * (nZbins + 2);
        h->Sumw2();
      }
      if (fVariableNames[varX][0] != 0) {
        h->GetXaxis()->SetTitle(Form("%s %s", fVariableNames[varX].Data(),
                                     ((fVariableUnits[varX][0] != 0) ? Form("(%s)", fVariableUnits[varX].Data()) : "")));
      }
      if (arr->At(1)) {
        h->GetXaxis()->SetTitle(arr->At(1)->GetName());
      }
      if (xLabels[0] != '\0') {
        MakeAxisLabels(h->GetXaxis(), xLabels);
      }
      if (fVariableNames[varY][0] != 0) {
        h->GetYaxis()->SetTitle(Form("%s %s", fVariableNames[varY].Data(),
                                     ((fVariableUnits[varY][0] != 0) ? Form("(%s)", fVariableUnits[varY].Data()) : "")));
      }
      if (arr->At(2)) {
        h->GetYaxis()->SetTitle(arr->At(2)->GetName());
      }
      if (yLabels[0] != '\0') {
        MakeAxisLabels(h->GetYaxis(), yLabels);
      }
      if (fVariableNames[varZ][0] != 0) {
        h->GetZaxis()->SetTitle(Form("%s %s", fVariableNames[varZ].Data(),
                                     ((fVariableUnits[varZ][0] != 0) ? Form("(%s)", fVariableUnits[varZ].Data()) : "")));
      }
      if ((fVariableNames[varZ][0] != 0) && isProfile && varT < 0) { // TProfile2D
        h->GetZaxis()->SetTitle(Form("<%s> %s", fVariableNames[varZ].Data(),
                                     ((fVariableUnits[varZ][0] != 0) ? Form("(%s)", fVariableUnits[varZ].Data()) : "")));
      }

      if (arr->At(3)) {
        h->GetZaxis()->SetTitle(arr->At(3)->GetName());
      }
      if (zLabels[0] != '\0') {
        MakeAxisLabels(h->GetZaxis(), zLabels);
      }
      hList->Add(h);
      break;

    default:
      LOG(warn) << "HistogramManager::AddHistogram(): Unsupported dimension " << dimension
                << " for histogram " << hname;
      return;
  } // end switch(dimension)
}

//_________________________________________________________________
void HistogramManager::AddHistogram(const char* histClass, const char* hname, const char* title,
                                    int nDimensions, int* vars, int* nBins, double* xmin, double* xmax,
                                    TString* axLabels, int varW, bool useSparse, bool isdouble)
{
  //
  // add a multi-dimensional histogram THnF or THnFSparseF
  //

  // get the list to which the histogram should be added
  auto* hList = dynamic_cast<TList*>(fMainList->FindObject(histClass));
  if (!hList) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram list " << histClass << " not found!";
    LOG(warn) << "         Histogram not created";
    return;
  }
  // check whether this histogram name was used before
  if (hList->FindObject(hname)) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram " << hname << " already exists";
    return;
  }

  // tokenize the title string; the user may include in it axis titles which will overwrite the defaults
  TString titleStr(title);
  std::unique_ptr<TObjArray> arr(titleStr.Tokenize(";"));

  if (varW > kNothing) {
    fUsedVars[varW] = kTRUE;
  }

  for (int i = 0; i < nDimensions; i++) {
    if (xmax[i] <= xmin[i]) {
      LOG(warn) << "HistogramManager::AddHistogram(): Histogram " << hname << " has wrong axes ranges for dimension " << i
                << ", (xmin/xmax): " << xmin[i] << " / " << xmax[i];
    }
  }

  // encode needed variable identifiers in a vector and push it to the std::list corresponding to the current histogram list
  std::vector<int> varVector;
  varVector.push_back(0);           // whether the histogram is a profile
  varVector.push_back(nDimensions); // number of dimensions
  varVector.push_back(varW);        // variable used for weighting
  for (int idim = 0; idim < nDimensions; ++idim) {
    varVector.push_back(vars[idim]); // axes variables
  }
  std::list varList = fVariablesMap[histClass];
  varList.push_back(varVector);
  fVariablesMap[histClass] = varList;

  uint32_t nbins = 1;
  THnBase* h = nullptr;
  if (!isdouble) {
    if (useSparse) {
      h = new THnSparseF(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    } else {
      h = new THnF(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    }
  } else {
    if (useSparse) {
      h = new THnSparseD(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    } else {
      h = new THnD(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    }
  }
  h->Sumw2();

  std::span<TString> axisLabels{};
  if (axLabels) {
    axisLabels = std::span<TString>{axLabels, static_cast<std::size_t>(nDimensions)};
  }

  // configure the THn histogram and count the allocated bins
  for (int idim = 0; idim < nDimensions; ++idim) {
    nbins *= (nBins[idim] + 2);
    TAxis* axis = h->GetAxis(idim);
    if (fVariableNames[vars[idim]][0] != 0) {
      axis->SetTitle(Form("%s %s", fVariableNames[vars[idim]].Data(),
                          ((fVariableUnits[vars[idim]][0] != 0) ? Form("(%s)", fVariableUnits[vars[idim]].Data()) : "")));
    }
    if (arr->At(1 + idim)) {
      axis->SetTitle(arr->At(1 + idim)->GetName());
    }
    if (!axisLabels.empty() && !axisLabels[idim].IsNull()) {
      MakeAxisLabels(axis, axisLabels[idim].Data());
    }

    fUsedVars[vars[idim]] = kTRUE;
  }
  if (!isdouble) {
    if (useSparse) {
      if (auto* hn = dynamic_cast<THnSparseF*>(h)) {
        hList->Add(hn);
      }
    } else if (auto* hn = dynamic_cast<THnF*>(h)) {
      hList->Add(hn);
    }
  } else {
    if (useSparse) {
      if (auto* hn = dynamic_cast<THnSparseD*>(h)) {
        hList->Add(hn);
      }
    } else if (auto* hn = dynamic_cast<THnD*>(h)) {
      hList->Add(hn);
    }
  }

  fBinsAllocated += nbins;
}

//_________________________________________________________________
void HistogramManager::AddHistogram(const char* histClass, const char* hname, const char* title,
                                    int nDimensions, int* vars, TArrayD* binLimits,
                                    TString* axLabels, int varW, bool useSparse, bool isdouble)
{
  //
  // add a multi-dimensional histogram THnF or THnSparseF with equal or variable bin widths
  //

  // get the list to which the histogram should be added
  auto* hList = dynamic_cast<TList*>(fMainList->FindObject(histClass));
  if (!hList) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram list " << histClass << " not found!";
    LOG(warn) << "         Histogram not created";
    return;
  }
  // check whether this histogram name was used before
  if (hList->FindObject(hname)) {
    LOG(warn) << "HistogramManager::AddHistogram(): Histogram " << hname << " already exists";
    return;
  }

  // tokenize the title string; the user may include in it axis titles which will overwrite the defaults
  TString titleStr(title);
  std::unique_ptr<TObjArray> arr(titleStr.Tokenize(";"));

  if (varW > kNothing) {
    fUsedVars[varW] = kTRUE;
  }

  // encode needed variable identifiers in a vector and push it to the std::list corresponding to the current histogram list
  std::vector<int> varVector;
  varVector.push_back(0);           // whether the histogram is a profile
  varVector.push_back(nDimensions); // number of dimensions
  varVector.push_back(varW);        // variable used for weighting
  for (int idim = 0; idim < nDimensions; ++idim) {
    varVector.push_back(vars[idim]); // axes variables
  }
  std::list varList = fVariablesMap[histClass];
  varList.push_back(varVector);
  fVariablesMap[histClass] = varList;

  // get the min and max for each axis
  auto* xmin = new double[nDimensions];
  auto* xmax = new double[nDimensions];
  int* nBins = new int[nDimensions];
  std::span<const TArrayD> limits{binLimits, static_cast<std::size_t>(nDimensions)};
  for (int idim = 0; idim < nDimensions; ++idim) {
    const TArrayD& dimLimits = limits[idim];
    const double* dimBins = dimLimits.GetArray();
    nBins[idim] = dimLimits.GetSize() - 1;
    xmin[idim] = dimBins[0];
    xmax[idim] = dimBins[nBins[idim]];
  }

  // initialize the THn with equal spaced bins
  THnBase* h = nullptr;
  if (!isdouble) {
    if (useSparse) {
      h = new THnSparseF(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    } else {
      h = new THnF(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    }
  } else {
    if (useSparse) {
      h = new THnSparseD(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    } else {
      h = new THnD(hname, (arr->At(0) ? arr->At(0)->GetName() : ""), nDimensions, nBins, xmin, xmax);
    }
  }
  // rebin the axes according to the user requested binning
  for (int idim = 0; idim < nDimensions; ++idim) {
    TAxis* axis = h->GetAxis(idim);
    axis->Set(nBins[idim], limits[idim].GetArray());
  }
  h->Sumw2();

  std::span<TString> axisLabels{};
  if (axLabels) {
    axisLabels = std::span<TString>{axLabels, static_cast<std::size_t>(nDimensions)};
  }

  uint32_t bins = 1;
  for (int idim = 0; idim < nDimensions; ++idim) {
    bins *= (nBins[idim] + 2);
    TAxis* axis = h->GetAxis(idim);
    if (fVariableNames[vars[idim]][0] != 0) {
      axis->SetTitle(Form("%s %s", fVariableNames[vars[idim]].Data(),
                          ((fVariableUnits[vars[idim]][0] != 0) ? Form("(%s)", fVariableUnits[vars[idim]].Data()) : "")));
    }
    if (arr->At(1 + idim)) {
      axis->SetTitle(arr->At(1 + idim)->GetName());
    }
    if (!axisLabels.empty() && !axisLabels[idim].IsNull()) {
      MakeAxisLabels(axis, axisLabels[idim].Data());
    }
    fUsedVars[vars[idim]] = kTRUE;
  }
  if (!isdouble) {
    if (useSparse) {
      if (auto* hn = dynamic_cast<THnSparseF*>(h)) {
        hList->Add(hn);
      }
    } else if (auto* hn = dynamic_cast<THnF*>(h)) {
      hList->Add(hn);
    }
  } else {
    if (useSparse) {
      if (auto* hn = dynamic_cast<THnSparseD*>(h)) {
        hList->Add(hn);
      }
    } else if (auto* hn = dynamic_cast<THnD*>(h)) {
      hList->Add(hn);
    }
  }
  fBinsAllocated += bins;
}

//__________________________________________________________________
void HistogramManager::FillHistClass(const char* className, float* values)
{
  //
  //  fill a class of histograms
  //

  // get the needed histogram list
  auto* hList = dynamic_cast<TList*>(fMainList->FindObject(className));
  if (!hList) {
    // TODO: add some meaningfull error message
    /*LOG(warn) << "HistogramManager::FillHistClass(): Histogram list " << className << " not found!";
    LOG(warn) << "         Histogram list not filled" << endl; */
    return;
  }

  // get the corresponding std::list containng identifiers to the needed variables to be filled
  auto const& varList = fVariablesMap[className];

  TIter next(hList);

  TObject* h = nullptr;
  bool isProfile = false;
  bool isTHn = false;
  int dimension = 0;
  bool isFillLabelx = kFALSE;
  // TODO: At the moment, maximum 20 dimensions are foreseen for the THn histograms. We should make this more dynamic
  //       But maybe its better to have it like to avoid dynamically allocating this array in the histogram loop
  std::array<double, 20> fillValues{};
  int varX = -1, varY = -1, varZ = -1, varT = -1, varW = -1;

  // loop over the histogram and std::list
  // NOTE: these two should contain the same number of elements and be synchronized, otherwise its a mess
  for (auto varIter = varList.begin(); varIter != varList.end(); varIter++) {
    h = next(); // get the histogram
    // decode information from the vector of indices
    isProfile = ((*varIter)[0] == 1);
    isTHn = ((*varIter)[1] > 0);
    if (isTHn) {
      dimension = (*varIter)[1];
    } else if (auto* h1 = dynamic_cast<TH1*>(h)) {
      dimension = h1->GetDimension();
    } else {
      continue;
    }

    // get the various variable indices
    varW = (*varIter)[2];
    if (isTHn) {
      for (int i = 0; i < dimension; i++) {
        fillValues[i] = values[(*varIter)[3 + i]];
      }
    } else {
      varX = (*varIter)[3];
      varY = (*varIter)[4];
      varZ = (*varIter)[5];
      varT = (*varIter)[6];
      isFillLabelx = ((*varIter)[7] == 1);
    }

    if (!isTHn) {
      switch (dimension) {
        case 1:
          if (isProfile) {
            auto* profile = dynamic_cast<TProfile*>(h);
            if (!profile) {
              break;
            }
            if (varW > kNothing) {
              if (isFillLabelx) {
                profile->Fill(Form("%d", static_cast<int>(values[varX])), values[varY], values[varW]);
              } else {
                profile->Fill(values[varX], values[varY], values[varW]);
              }
            } else {
              if (isFillLabelx) {
                profile->Fill(Form("%d", static_cast<int>(values[varX])), values[varY]);
              } else {
                profile->Fill(values[varX], values[varY]);
              }
            }
          } else {
            auto* h1 = dynamic_cast<TH1*>(h);
            if (!h1) {
              break;
            }
            if (varW > kNothing) {
              if (isFillLabelx) {
                h1->Fill(Form("%d", static_cast<int>(values[varX])), values[varW]);
              } else {
                h1->Fill(values[varX], values[varW]);
              }
            } else {
              if (isFillLabelx) {
                h1->Fill(Form("%d", static_cast<int>(values[varX])), 1.);
              } else {
                h1->Fill(values[varX]);
              }
            }
          }
          break;
        case 2:
          if (isProfile) {
            auto* profile = dynamic_cast<TProfile2D*>(h);
            if (!profile) {
              break;
            }
            if (varW > kNothing) {
              profile->Fill(values[varX], values[varY], values[varZ], values[varW]);
            } else {
              profile->Fill(values[varX], values[varY], values[varZ]);
            }
          } else {
            auto* h2 = dynamic_cast<TH2*>(h);
            if (!h2) {
              break;
            }
            if (varW > kNothing) {
              if (isFillLabelx) {
                h2->Fill(Form("%d", static_cast<int>(values[varX])), values[varY], values[varW]);
              } else {
                h2->Fill(values[varX], values[varY], values[varW]);
              }
            } else {
              if (isFillLabelx) {
                h2->Fill(Form("%d", static_cast<int>(values[varX])), values[varY], 1.);
              } else {
                h2->Fill(values[varX], values[varY]);
              }
            }
          }
          break;
        case 3:
          if (isProfile) {
            auto* profile = dynamic_cast<TProfile3D*>(h);
            if (!profile) {
              break;
            }
            if (varW > kNothing) {
              profile->Fill(values[varX], values[varY], values[varZ], values[varT], values[varW]);
            } else {
              profile->Fill(values[varX], values[varY], values[varZ], values[varT]);
            }
          } else {
            auto* h3 = dynamic_cast<TH3*>(h);
            if (!h3) {
              break;
            }
            if (varW > kNothing) {
              h3->Fill(values[varX], values[varY], values[varZ], values[varW]);
            } else {
              h3->Fill(values[varX], values[varY], values[varZ]);
            }
          }
          break;

        default:
          break;
      } // end switch
      // end if(!isTHn)
    } else {
      if (varW > kNothing) {
        if (auto* hn = dynamic_cast<THnSparse*>(h)) {
          hn->Fill(fillValues.data(), values[varW]);
        } else if (auto* hn = dynamic_cast<THn*>(h)) {
          hn->Fill(fillValues.data(), values[varW]);
        }
      } else {
        if (auto* hn = dynamic_cast<THnSparse*>(h)) {
          hn->Fill(fillValues.data());
        } else if (auto* hn = dynamic_cast<THn*>(h)) {
          hn->Fill(fillValues.data());
        }
      }
    } // end else
  } // end loop over histograms
}

//____________________________________________________________________________________
void HistogramManager::MakeAxisLabels(TAxis* ax, const char* labels)
{
  //
  // add bin labels to an axis
  //
  TString labelsStr(labels);
  std::unique_ptr<TObjArray> arr(labelsStr.Tokenize(";"));
  for (int ib = 1; ib <= ax->GetNbins(); ++ib) {
    if (ib >= arr->GetEntries() + 1) {
      break;
    }
    ax->SetBinLabel(ib, arr->At(ib - 1)->GetName());
  }
}

//____________________________________________________________________________________
void HistogramManager::Print(Option_t*) const
{
  //
  // Print the defined histograms
  //
  LOG(info) << "###################################################################";
  LOG(info) << "HistogramManager:: " << fMainList->GetName();
  for (int i = 0; i < fMainList->GetEntries(); ++i) {
    auto* histList = dynamic_cast<TList*>(fMainList->At(i));
    if (!histList) {
      continue;
    }
    LOG(info) << "************** List " << histList->GetName();
    for (int j = 0; j < histList->GetEntries(); ++j) {
      TObject* obj = histList->At(j);
      LOG(info) << obj->GetName() << ": " << obj->IsA()->GetName();
    }
  }
}
