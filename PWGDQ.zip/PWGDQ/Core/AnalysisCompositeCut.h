// Copyright 2019-2020 CERN and copyright holders of ALICE O2.
// See https://alice-o2.web.cern.ch/copyright for details of the copyright holders.
// All rights not expressly granted are reserved.
//
// This software is distributed under the terms of the GNU General Public
// License v3 (GPL Version 3), copied verbatim in the file "COPYING".
//
// In applying this license CERN does not waive the privileges and immunities
// granted to it by virtue of its status as an Intergovernmental Organization
// or submit itself to any jurisdiction.
//
// Contact: iarsene@cern.ch, i.c.arsene@fys.uio.no
//
// Cut class manipulating groups of cuts
//

#ifndef PWGDQ_CORE_ANALYSISCOMPOSITECUT_H_
#define PWGDQ_CORE_ANALYSISCOMPOSITECUT_H_

#include "PWGDQ/Core/AnalysisCut.h"

#include <RtypesCore.h>

#include <vector>

//_________________________________________________________________________
class AnalysisCompositeCut : public AnalysisCut
{
 public:
  AnalysisCompositeCut(bool useAND = kTRUE);
  AnalysisCompositeCut(const char* name, const char* title, bool useAND = kTRUE);
  AnalysisCompositeCut(const AnalysisCompositeCut& c);
  AnalysisCompositeCut& operator=(const AnalysisCompositeCut& c);
  ~AnalysisCompositeCut() override;

  void AddCut(AnalysisCut* cut)
  {
    if (auto* composite = dynamic_cast<AnalysisCompositeCut*>(cut)) {
      fCompositeCutList.push_back(*composite);
    } else {
      fCutList.push_back(*cut);
    }
  };

  bool GetUseAND() const { return fOptionUseAND; }
  int GetNCuts() const { return fCutList.size() + fCompositeCutList.size(); }

  bool IsSelected(float* values) override;

 protected:
  bool fOptionUseAND;                                  // true (default): apply AND on all cuts; false: use OR
  std::vector<AnalysisCut> fCutList;                   // list of cuts
  std::vector<AnalysisCompositeCut> fCompositeCutList; // list of composite cuts
};

#endif // PWGDQ_CORE_ANALYSISCOMPOSITECUT_H_
